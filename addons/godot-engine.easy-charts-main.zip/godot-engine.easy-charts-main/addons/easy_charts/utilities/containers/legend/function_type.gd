extends Label
class_name FunctionTypeLabel

var type: int
var marker: int
var color: Color
var icon: Texture2D

var indicator_visible: bool:
	get:
		return indicator_visible
	set(value):
		indicator_visible = value
		queue_redraw()

func _draw() -> void:
	if !indicator_visible:
		return

	if icon == null:
		_draw_function_and_marker()
	else:
		_draw_icon()

func _draw_function_and_marker() -> void:
	var center: Vector2 = get_rect().get_center()

	match self.type:
		Function.Type.LINE:
			draw_line(
				Vector2(get_rect().position.x, center.y),
				Vector2(get_rect().end.x, center.y),
				color, 3
			)
		Function.Type.AREA:
			var color_light: Color = color
			color_light.a = 0.3
			draw_rect(
				Rect2(
					Vector2(get_rect().position.x, center.y),
					Vector2(get_rect().end.x, get_rect().end.y / 2)
				),
				color_light,
				true
			)
			draw_line(
				Vector2(get_rect().position.x, center.y),
				Vector2(get_rect().end.x, center.y),
				color,
				3
			)
		Function.Type.PIE:
			draw_rect(
				Rect2(center - (Vector2.ONE * 3), (Vector2.ONE * 3 * 2)),
				color,
				true
			)
		Function.Type.BAR:
			draw_rect(
				Rect2(
					Vector2(get_rect().position),
					Vector2(get_rect().end.x, get_rect().end.y)
				),
				color,
				true
			)
		Function.Type.RADAR:
			var r := minf(get_rect().size.x, get_rect().size.y) * 0.45
			draw_circle(center, r, Color(color.r, color.g, color.b, 0.35))
			draw_arc(center, r, 0.0, TAU, 24, color, 2.0)
		Function.Type.SCATTER, _:
			pass

	match self.marker:
		Function.Marker.NONE:
			pass
		Function.Marker.SQUARE:
			draw_rect(
				Rect2(center - (Vector2.ONE * 3), (Vector2.ONE * 3 * 2)), 
				color,
				true
			)
		Function.Marker.TRIANGLE:
			draw_colored_polygon(
				PackedVector2Array([
					center + (Vector2.UP * 3 * 1.3),
					center + (Vector2.ONE * 3 * 1.3),
					center - (Vector2(1, -1) * 3 * 1.3)
				]), color, [], null
			)
		Function.Marker.CROSS:
			draw_line(
				center - (Vector2.ONE * 3),
				center + (Vector2.ONE * 3),
				color, 3, true
			)
			draw_line(
				center + (Vector2(1, -1) * 3),
				center + (Vector2(-1, 1) * 3),
				color, 3 / 2, true
			)
		Function.Marker.CIRCLE, _:
			draw_circle(center, 3, color)

func _draw_icon() -> void:
	draw_texture_rect(icon, get_rect(), false, color)
