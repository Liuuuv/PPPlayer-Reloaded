extends Control

@onready var chart: Chart = $VBoxContainer/Chart

# This Chart will plot 3 different functions
var f1: Function

func _ready():
	# Let's create our @x values
	var x: Array = [100, 400]
	
	# And our y values. It can be an n-size array of arrays.
	# NOTE: `x.size() == y.size()` or `x.size() == y[n].size()`
	var y: Array = ["Java", "JavaScript", "C++", "GDScript"]
	
	# Let's customize the chart properties, which specify how the chart
	# should look, plus some additional elements like labels, the scale, etc...
	var cp: ChartProperties = ChartProperties.new()
	cp.title = "Users preferences on programming languages"
	cp.draw_grid_box = false
	cp.show_legend = true
	cp.interactive = true # false by default, it allows the chart to create a tooltip to show point values
	# and interecept clicks on the plot
	
	var gradient: Gradient = Gradient.new()
	gradient.set_color(0, Color.AQUAMARINE)
	gradient.set_color(1, Color.DEEP_PINK)
	
	# Let's add values to our functions
	f1 = Function.new(
		x, y, "Language", # This will create a function with x and y values taken by the Arrays 
						# we have created previously. This function will also be named "Pressure"
						# as it contains 'pressure' values.
						# If set, the name of a function will be used both in the Legend
						# (if enabled thourgh ChartProperties) and on the Tooltip (if enabled).
		{
			gradient = gradient,
			type = Function.Type.PIE
		}
	)
	
	# Now let's plot our data
	chart.plot([f1], cp)
	
	# Uncommenting this line will show how real time data plotting works
	set_process(false)


var new_val: int = 20

func _process(delta: float):
	# This function updates the values of a function and then updates the plot
	new_val += 10

	# we can use the `Function.add_point(x, y)` method to update a function
	f1.add_point(new_val, "C++ %s" % new_val)
	chart.queue_redraw() # This will force the Chart to be updated


func _on_CheckButton_pressed():
	set_process(not is_processing())
